__ace_shadowed__.define('ace/snippets/jsoniq', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "jsoniq";

});
